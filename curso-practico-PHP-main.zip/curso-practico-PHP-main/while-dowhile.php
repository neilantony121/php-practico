<?php

$i = 0;
do {
    echo $i++;
} while ($i <= 10);
?>