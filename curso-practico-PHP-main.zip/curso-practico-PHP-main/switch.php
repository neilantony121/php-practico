<?php
$valorA = 3;

switch($valorA) {
    case 1:
        echo "El valor es 1";
    break;
    case 2:
        echo "El valor es 2";
    break;
    case 3:
        echo "El valor es 3";
    break;
    default:
        echo "No es ninguno de los valores 1, 2 o 3";
    break;
}
?>