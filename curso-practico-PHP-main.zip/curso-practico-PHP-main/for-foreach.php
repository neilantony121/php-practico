<?php
$arr = array(1,2,3,4);
foreach($arr as $value) {
    echo $value;
}

?>