# Curso Práctico de PHP

### Hola Platzinauta!

En este repositorio podrás encontrar el código que hicimos en nuestro Curso Práctico de PHP donde hemos aprendido a utilizar nuestro lenguaje favorito y realizar un proyecto muy interesante para ordenar palabras.